package com.uttarainfo.restclient.dbmapper;

import java.util.List;

import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Service;

import com.uttarainfo.restclient.model.Login;

public interface LoginMapper {

@Results({
	@Result(id = true, property = "Id", column = "Id"),
		@Result(property = "userName", column = "NAME"),
	@Result(property = "password", column = "PASSWORD")
		
})	
	@Select("Select NAME as userName, PASSWORD as password from Party")
	public List<Login> getLoginDetailsFromDB();


@Select("Select PASSWORD as password from Party where MOBILE_NO = #{mobileNo}")
public String getUserPwFromDB(String mobileNo);

@Select("select count(*) from party where MOBILE_NO = #{mobileNo}")
public int getRegUserMobNum(String mobileNo);

}
