package com.uttarainfo.restclient.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uttarainfo.restclient.model.Category;
import com.uttarainfo.restclient.service.CategoryService;

@Controller
public class CategoryController {
	
	@Autowired
	private CategoryService catgService;	
	

	public CategoryService getCatgService() {
		return catgService;
	}



	public void setCatgService(CategoryService catgService) {
		this.catgService = catgService;
	}



	@RequestMapping(value = "/categories", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public ResponseEntity<List<Category>> getAllProducts(){		
		try{
			List<Category> newProducts = new ArrayList<Category>();
			newProducts = catgService.getAllProducts();
			for(Category p : newProducts){	
				
				List<Category> subCatgProducts = catgService.getProductsOnCategoryId(p.getItem_id());
			
				for(Category subCatg :subCatgProducts){
					p.addChildren(subCatg.getItem_id(), subCatg.getName());
					//System.out.println(p);
					//System.out.println("================");
				}
				
				
			}
			System.out.println(newProducts);
			
			return new ResponseEntity<>(newProducts, HttpStatus.OK);
			
		}
		
		catch(SQLException ex)
		{
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		catch(Exception e)
		{
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
	}
	
	/*@RequestMapping(value = "/categories/{categoryId}", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public ResponseEntity<List<Product>> getProductsOnCategoryId( @PathVariable("categoryId") String categoryId){	
		
		System.out.println("categoryId   "+categoryId);
		try{
			List<Product> newProducts = new ArrayList<Product>();
			newProducts = prodService.getProductsOnCategoryId(categoryId);
			
				System.out.println(newProducts);
				System.out.println("==================================");
				 return new ResponseEntity<>(newProducts, HttpStatus.OK);
			}
		
		
		catch(SQLException ex)
		{
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		catch(Exception e)
		{
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
	}*/

}
