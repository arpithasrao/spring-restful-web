package com.uttarainfo.restclient.model;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Component("product")
public class Product {
	
	private String prodName;
	private double prodPrice;
	private int item_Sl;
	private double range1;
	private double range2;
	
	public Product(){
		
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public double getProdprice() {
		return prodPrice;
	}

	public void setProdprice(double prodprice) {
		this.prodPrice = prodprice;
	}

	public int getItem_Sl() {
		return item_Sl;
	}

	public void setItem_Sl(int item_Sl) {
		this.item_Sl = item_Sl;
	}

	@JsonIgnore
	public double getRange1() {
		return range1;
	}

	public void setRange1(double range1) {
		this.range1 = range1;
	}

	@JsonIgnore
	public double getRange2() {
		return range2;
	}

	public void setRange2(double range2) {
		this.range2 = range2;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + item_Sl;
		result = prime * result + ((prodName == null) ? 0 : prodName.hashCode());
		long temp;
		temp = Double.doubleToLongBits(prodPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(range1);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(range2);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (item_Sl != other.item_Sl)
			return false;
		if (prodName == null) {
			if (other.prodName != null)
				return false;
		} else if (!prodName.equals(other.prodName))
			return false;
		if (Double.doubleToLongBits(prodPrice) != Double.doubleToLongBits(other.prodPrice))
			return false;
		if (Double.doubleToLongBits(range1) != Double.doubleToLongBits(other.range1))
			return false;
		if (Double.doubleToLongBits(range2) != Double.doubleToLongBits(other.range2))
			return false;
		return true;
	}

	public Product(String prodName, double prodprice, int item_Sl, double range1, double range2) {
		super();
		this.prodName = prodName;
		this.prodPrice = prodprice;
		this.item_Sl = item_Sl;
		this.range1 = range1;
		this.range2 = range2;
	}

	@Override
	public String toString() {
		return "Product prodName=" + prodName + ", prodprice=" + prodPrice + ", item_Sl=" + item_Sl + ", range1="
				+ range1 + ", range2=" + range2 + "\n";
	}

	
	
	
	

}
