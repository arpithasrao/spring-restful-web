package com.uttarainfo.restclient.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.List;
import java.util.Random;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.uttarainfo.restclient.model.Login;
import com.uttarainfo.restclient.service.LoginService;
import com.uttarainfo.restclient.utils.OTP;
import com.uttarainfo.restclient.utils.ResponseStatusCode;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

@Controller
public class RegistrationController {
	
	@Autowired(required=true)
	private LoginService loginService;
	
	
	public LoginService getLoginService() {
		return loginService;
	}

   
	public void setLoginService(LoginService loginService) {
		this.loginService = loginService;
	}
	
	@RequestMapping(value = "/registration",method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public OTP getRegDetails() throws ClientProtocolException, IOException{
		
		final String url = "http://localhost:8090/SpringRest/registration";
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders requestHeaders = new HttpHeaders();
		
		requestHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Login> requestEntity = new HttpEntity<Login>(requestHeaders);

		// Make the HTTP GET request, marshaling the response from JSON to an array of Events
		ResponseEntity<List<Login>> responseEntity = restTemplate.exchange(url, HttpMethod.GET, requestEntity, 
				new ParameterizedTypeReference<List<Login>>(){});
		List<Login> loginList = responseEntity.getBody();
		
		Login mobileNoBean = loginList.get(0);
		String mobileNo = mobileNoBean.getMobileNo();		
		int mobileNoCount = loginService.getRegUserMobNum(mobileNo);
		System.out.println("mobileNo ... "+mobileNoCount);
		
		if(mobileNoCount != 0)
		{
			System.out.println("User already registered!!!\n");
			return new OTP(ResponseStatusCode.STS_MOB_REG, ResponseStatusCode.STS_MSG_INVALID_OTP);
		}
		else
		{
			int otpnumber =  generateOtp();
			System.out.println("New user .. OTP generated .."+ otpnumber);
			
			String urlServer = postOtpToServer(otpnumber, mobileNo);
			HttpClient client = HttpClientBuilder.create().build();
			HttpPost post = new HttpPost(urlServer);

			HttpResponse response = client.execute(post);
			System.out.println("Response Code : "
			                + response.getStatusLine().getStatusCode());

			BufferedReader rd = new BufferedReader(
			        new InputStreamReader(response.getEntity().getContent()));

			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}			
			return new OTP(otpnumber,mobileNo, ResponseStatusCode.STS_OTP_SENT, ResponseStatusCode.STS_MSG_OTP_SENT);
		}
		
		
	}
	
	//generate 4 digit otp number
	private int generateOtp(){
	
		Random randomNum = new Random();
		String otp = String.format("%04d", randomNum.nextInt(10000));
		int otpnumber = Integer.parseInt(otp);
		return otpnumber;
	}
	
	//create the URI for testing server
	private  String postOtpToServer(int otp, String mobileNo){
		
		
		String finalMobNo = addCountryCodeToMobNo(mobileNo);
		
		//String uri = "https://smsc.vianett.no/v3/send?";
		String uri = "http://login.cheapsmsbazaar.com/vendorsms/pushsms.aspx?";
		String user	= "user=Arpitha";
		String password= "&password=Sucess123";
		String msisdn = "&msisdn="+finalMobNo;
		String sid = "&sid=DEMOOO";
		String msg ="&msg=EzyBiz"+ otp ;
		String fl = "&fl=0";

	    StringBuilder sb = new StringBuilder();
	    sb.append(uri);
	    sb.append(user);
	    sb.append(password);
	    sb.append(msisdn);
	    sb.append(sid);
	    sb.append(msg);
	    sb.append(fl);
	    System.out.println(sb.toString());
	    
	    return sb.toString();
		
	}
	
	//check whether phone number is pre appended with country code
	private boolean checkMobNoForCountryCode(String mobileNo)
	{
		if(mobileNo.startsWith("+91"))
			return true;
		else
			return false;
	}

	//if the mobile number is not pre -appended with country code, append mobile number with country code 
	private String addCountryCodeToMobNo(String mobileNo){
		String finalMobNo = "";
		boolean ccFlag = checkMobNoForCountryCode(mobileNo);
		if(!(ccFlag))
		{
			finalMobNo = "+91"+ mobileNo;
			return finalMobNo;
		}
		return mobileNo;
}
}