package com.uttarainfo.restclient.dbmapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.uttarainfo.restclient.model.Product;

public interface ProductMapper {
	
String prodBasedOnPrice = "select s.ITEM_SL,s.PRICE, w.GR_NAME from sprice s inner join GOG_VIEW2 w on w.IGR_SL2 = s.ITEM_SL where s.PRICE between #{range1} AND #{range2} AND w.IGR_SL = #{item_Sl}";

@Results({
		@Result(property = "item_Sl", column = "ITEM_SL"),
		@Result(property = "prodName", column = "GR_NAME"),
		@Result(property = "prodPrice", column = "PRICE")
		
})

@Select(prodBasedOnPrice)
public List<Product> getProdsOnPrice(@Param("item_Sl") int item_Sl, @Param("range1") double range1, @Param("range2") double range2);

}
