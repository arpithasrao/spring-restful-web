package com.uttarainfo.restclient.utils;

import org.springframework.stereotype.Component;

@Component("ResposeStatus")
public class ResposeStatus {
	
	private int statusCode;
	private String statusMsg;
	
	public ResposeStatus(){
		
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	public ResposeStatus(int statusCode, String statusMsg) {
		super();
		this.statusCode = statusCode;
		this.statusMsg = statusMsg;
	}
	@Override
	public String toString() {
		return "ResposeStatusCode statusCode=" + statusCode + ", statusMsg=" + statusMsg + "";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + statusCode;
		result = prime * result + ((statusMsg == null) ? 0 : statusMsg.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ResposeStatus other = (ResposeStatus) obj;
		if (statusCode != other.statusCode)
			return false;
		if (statusMsg == null) {
			if (other.statusMsg != null)
				return false;
		} else if (!statusMsg.equals(other.statusMsg))
			return false;
		return true;
	}
	

}
