package com.uttarainfo.restclient.service;

import java.sql.SQLException;
import java.util.List;

import com.uttarainfo.restclient.model.Category;

public interface CategoryService  {
	
	public List<Category> getAllProducts() throws SQLException;
	public List<Category> getProductsOnCategoryId(long categoryId) throws SQLException; 

}
