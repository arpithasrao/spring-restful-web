package com.uttarainfo.restclient.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.uttarainfo.restclient.utils.ResposeStatus;

@Component("category")
public class Category {
	
		
	//private long sl_no;
	private long item_id;	
	private String name;
	//private String login;
	//private Date entry_date;
	
	private List<Category> children = new ArrayList<Category>();
	
	
	public Category(){
		
	}

	public long getItem_id() {
		return item_id;
	}



	public void setItem_id(long item_id) {
		this.item_id = item_id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public List<Category> getChildren() {
		return children;
	}



	public void setChildren(List<Category> children) {
		this.children = children;
	}

	
	public Category(long item_id, String name, List<Category> children) {
		super();
		this.item_id = item_id;
		this.name = name;
		this.children = children;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((children == null) ? 0 : children.hashCode());
		result = prime * result + (int) (item_id ^ (item_id >>> 32));
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Category other = (Category) obj;
		if (children == null) {
			if (other.children != null)
				return false;
		} else if (!children.equals(other.children))
			return false;
		if (item_id != other.item_id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "Category [item_id=" + item_id + ", name=" + name + ", children=" + children + "]";
	}



	public void addChildren(long item_id, String name ){
		
		Category child = new Category();
		child.setItem_id(item_id);
		child.setName(name);
		children.add(child);
		
	}

	



	

}

/*public String getCo_code() {
return co_code;
}

public void setCo_code(String co_code) {
this.co_code = co_code;
}

public String getCode() {
return code;
}

public void setCode(String code) {
this.code = code;
}
*/

/*public String getLogin() {
return login;
}

public void setLogin(String login) {
this.login = login;
}


//serialize java date to JSON response
@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone = "IST")
public Date getEntry_date() {
return entry_date;
}

public void setEntry_date(Date entry_date) {
this.entry_date = entry_date;
}

public Product(long sl_no, String co_code, String code, String name, String login, Date entry_date) {
super();
this.sl_no = sl_no;
this.co_code = co_code;
this.code = code;
this.name = name;
this.login = login;
this.entry_date = entry_date;
}*/