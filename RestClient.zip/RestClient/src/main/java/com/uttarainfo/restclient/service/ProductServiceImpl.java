package com.uttarainfo.restclient.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uttarainfo.restclient.dbmapper.ProductMapper;
import com.uttarainfo.restclient.model.Product;

@Service("prodService")
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductMapper prodMapper;
	
	
	public ProductMapper getProdMapper() {
		return prodMapper;
	}


	public void setProdMapper(ProductMapper prodMapper) {
		this.prodMapper = prodMapper;
	}


	@Override
	public List<Product> getProdsOnPrice(int item_sl,double range1, double range2) {
		System.out.println("item_sl ..."+ item_sl);
		return prodMapper.getProdsOnPrice(item_sl,range1, range2);
	}

}
