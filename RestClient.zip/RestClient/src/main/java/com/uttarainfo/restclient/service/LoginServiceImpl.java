package com.uttarainfo.restclient.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uttarainfo.restclient.dbmapper.LoginMapper;
import com.uttarainfo.restclient.model.Login;

@Service("loginService")
public class LoginServiceImpl implements LoginService {
	
	@Autowired
	private LoginMapper loginMapper;	
	
	
	public LoginMapper getLoginMapper() {
		return loginMapper;
	}

	
	public void setLoginMapper(LoginMapper loginMapper) {
		this.loginMapper = loginMapper;
	}

	public List<Login> getLoginDetailsFromDB() {		
		return loginMapper.getLoginDetailsFromDB();
		
	}
	
	public String getUserPwFromDB(String mobileNo){		
		return loginMapper.getUserPwFromDB(mobileNo);
	}
	
	public int getRegUserMobNum(String mobileNo){
		return loginMapper.getRegUserMobNum(mobileNo);
	}

}
