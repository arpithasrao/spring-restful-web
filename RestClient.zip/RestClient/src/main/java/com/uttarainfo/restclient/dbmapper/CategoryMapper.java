package com.uttarainfo.restclient.dbmapper;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.uttarainfo.restclient.model.Category;

public interface CategoryMapper {
	
	final String productsOnCatgIdQy = "select gog_view2.IGR_SL2 as item_id, gog_view2.ITEM_NAME as name from GOG_VIEW2 inner join gog on GOG_VIEW2.IGR_SL2 = gog.IGR_SL2 inner join igr on gog.IGR_SL = igr.SL_NO where igr.SL_NO = #{categoryId}";
	

	@Results({
		@Result(id = true, property = "Id", column = "Id"),		
		@Result(property = "item_id", column = "IGR_SL"),
		@Result(property = "name", column = "NAME")
	})
	
	@Select("select distinct igr_sl, r.name  from rtgs.gog g2, rtgs.igr r where r.sl_no = g2.igr_sl")
	public List<Category> getAllProductsFromDB() throws SQLException;
	
	
	@Results({
		@Result(id = true, property = "Id", column = "Id"),
		@Result(property = "item_id", column = "IGR_SL2"),
		@Result(property = "name", column = "NAME")
	})
	
	@Select(productsOnCatgIdQy)
	public List<Category> getProdOnCatgIdFromDB(long categoryId) throws SQLException;


	
	
}
