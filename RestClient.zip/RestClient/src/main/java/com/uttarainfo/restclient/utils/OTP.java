package com.uttarainfo.restclient.utils;

import org.springframework.stereotype.Component;

@Component("otp")
public class OTP extends ResposeStatus{

	private int optCode;
	private String mobileNo;
	
	public OTP(){
		
	}
	public int getOptCode() {
		return optCode;
	}
	public void setOptCode(int optCode) {
		this.optCode = optCode;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	
	public OTP(int optCode, String mobileNo,int statusCode, String statusMsg) {
		super( statusCode, statusMsg);
		this.optCode = optCode;
		this.mobileNo = mobileNo;
	}

	
	public OTP(int statusCode, String statusMsg) {
		super(statusCode, statusMsg);
	}
	
	@Override
	public String toString() {
		return "OTP optCode=" + optCode + ", mobileNo=" + mobileNo + "";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((mobileNo == null) ? 0 : mobileNo.hashCode());
		result = prime * result + optCode;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OTP other = (OTP) obj;
		if (mobileNo == null) {
			if (other.mobileNo != null)
				return false;
		} else if (!mobileNo.equals(other.mobileNo))
			return false;
		if (optCode != other.optCode)
			return false;
		return true;
	}
	
	
	
}
