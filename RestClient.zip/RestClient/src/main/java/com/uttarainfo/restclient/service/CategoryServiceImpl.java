package com.uttarainfo.restclient.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uttarainfo.restclient.dbmapper.CategoryMapper;
import com.uttarainfo.restclient.model.Category;

@Service("catgService")
public class CategoryServiceImpl implements CategoryService {
	
	@Autowired
	private CategoryMapper catgMapper;

	public CategoryMapper getProdMapper() {
		return catgMapper;
	}

	public void setProdMapper(CategoryMapper catgMapper) {
		this.catgMapper = catgMapper;
	}	

	public List<Category> getAllProducts() throws SQLException{
		return catgMapper.getAllProductsFromDB();
	}
	
	public List<Category> getProductsOnCategoryId(long categoryId) throws SQLException{		
		return catgMapper.getProdOnCatgIdFromDB(categoryId);
	}

}
