package com.uttarainfo.restclient.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.uttarainfo.restclient.model.Product;
import com.uttarainfo.restclient.service.ProductService;

@Controller
public class ProductController {
	
	@Autowired
	private ProductService prodService;

	public ProductService getProdService() {
		return prodService;
	}

	public void setProdService(ProductService prodService) {
		this.prodService = prodService;
	}
	
	
	@RequestMapping(value = "/products", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<Product>> getProdsOnPrice(@RequestParam(value = "ITEM_SL", required = false) Integer item_Sl, @RequestParam (value = "from", required = false) Double range1,@RequestParam(value = "to", required = false) Double range2){
		
		System.out.println("item_Sl  "+ item_Sl +"  range1  "+range1 + "  range2  "+range2);
		List<Product> products = prodService.getProdsOnPrice( item_Sl, range1, range2);
		for(Product p : products){
			
			System.out.println(p);
		}
		
		return new ResponseEntity<>(products, HttpStatus.OK);
		
		
	}

}
