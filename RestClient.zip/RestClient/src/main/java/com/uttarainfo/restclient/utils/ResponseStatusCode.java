package com.uttarainfo.restclient.utils;

public interface ResponseStatusCode{
	
	final static int STS_CODE_SUCESS = 200;
	final static int STS_INVALID_MOB_OR_PW = 205;
	final static String STS_MSG_SUCESS = "SUCESS";
	final static String STS_MSG_INVALID_MOB_OR_PW = "INVALID MOBILE NUMBER OR PASSOWRD";
	final static int STS_MOB_REG = 206;
	final static String STS_MSG_INVALID_OTP = "INVALID OTP NUMBER";
	final static int STS_OTP_SENT = 207;
	final static String STS_MSG_OTP_SENT = "OTP SENT";
}
