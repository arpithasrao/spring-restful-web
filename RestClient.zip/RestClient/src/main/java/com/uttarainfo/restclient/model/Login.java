package com.uttarainfo.restclient.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@Component

public class Login implements Serializable{
	
	private long Id;
	private String userName;
	private String password;
	private String mobileNo;
	
	private int otp;
	
	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Login(){
		
	}
	
	public Login(String userName, String password, String mobileNo) {
		this.userName = userName;
		this.password = password;
		this.mobileNo = mobileNo;
	}
	

	public Login(String userName, String password, String mobileNo, int otp) {
		super();
		this.userName = userName;
		this.password = password;
		this.mobileNo = mobileNo;
		this.otp = otp;
	}

	@Override
	public String toString() {
		return "Login - userName=" + userName + ", password=" + password + "\n";
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Login other = (Login) obj;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		return true;
	}

	

}

