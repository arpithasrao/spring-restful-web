package com.uttarainfo.restclient.service;

import java.util.List;

import com.uttarainfo.restclient.model.Product;


public interface ProductService {

	public List<Product> getProdsOnPrice(int  item_sl, double range1, double range2);
	
}
