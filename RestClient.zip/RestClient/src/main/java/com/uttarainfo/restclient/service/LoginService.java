package com.uttarainfo.restclient.service;

import java.util.List;

import com.uttarainfo.restclient.model.Login;

public interface LoginService{
	
	public List<Login> getLoginDetailsFromDB();
	
	public String getUserPwFromDB(String mobileNo);
	
	public int getRegUserMobNum(String mobileNo);
}